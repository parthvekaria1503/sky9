export const getObjectKeys = (obj) => {
  const keys = Object.keys(obj);
  return keys;
};
